
## Kringvarp plugin til XBMC ##


![logo](https://raw.github.com/dotfo/plugin.video.kringvarp/master/icon.png "Kringvarp Føroya")



Minnist nú til at rinda kringvarpsgjald!



